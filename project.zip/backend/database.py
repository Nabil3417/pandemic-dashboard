from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from datetime import datetime
import os
import certifi
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv('MONGO_URI')

try:
    client = MongoClient(
        MONGO_URI,
        server_api=ServerApi('1'),
        tlsCAFile=certifi.where(),
        tlsAllowInvalidCertificates=True,
        tlsAllowInvalidHostnames=True
    )
    client.admin.command('ping')
    print("✅ Connected to MongoDB Atlas!")
    db = client['bioguard_research']

except Exception as e:
    print(f"❌ Connection Error: {e}")
    exit(1)

social_posts = db['social_media_posts']
mobility_data = db['mobility_events']
wastewater_readings = db['wastewater_readings']

def test_connection():
    try:
        result = social_posts.insert_one({
            "text": "Test post from MongoDB Atlas",
            "timestamp": datetime.now(),
            "processed": False,
            "test": True
        })
        print("✅ MongoDB Atlas connected successfully!")
        print(f"✅ Test document ID: {result.inserted_id}")
        social_posts.delete_many({"test": True})
        print("✅ Test data cleaned up!")
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()