from scheduler import job_wdzmi_composite
job_wdzmi_composite()